import logo from './logo.svg';
import React from "react";
import { IconStrokeLightIconListApps } from "./IconStrokeLightIconListApps";
import { IconStrokeRegularIconListMonitorAlt1 } from "./IconStrokeRegularIconListMonitorAlt1";
import { Icons } from "./Icons";
import image1 from "./image-1.png";
import image3 from "./image-3.png";
import image from "./image.png";
import justiceLeague1 from "./justice-league-1.png";
import maskGroup from "./mask-group.png";
import rectangle8 from "./rectangle-8.svg";
import search from "./search.svg";
import './App.css';

function App() {
  return (
    <div className="home-page">
      <div className="div">
        <div className="text-wrapper">Recommended Movies</div>

        <img className="search" alt="Search" src={search} />

        <img className="rectangle" alt="Rectangle" src={rectangle8} />

        <div className="bottom-nav-pan">
          <div className="overlap">
            <Icons className="icon-stroke-regular-icon-list-reel" />
          </div>

          <div className="overlap-group">
            <IconStrokeLightIconListApps className="icon-stroke-light-icon-list-apps" />
          </div>

          <div className="icons-wrapper">
            <IconStrokeRegularIconListMonitorAlt1 className="icon-stroke-regular-icon-list-monitor-alt-1" />
          </div>
        </div>

        <div className="overlap-2">
          <div className="top-slide">
            <img className="mask-group" alt="Mask group" src={maskGroup} />

            <img className="img" alt="Mask group" src={image} />
          </div>

          <img className="image" alt="Image" src={image3} />

          <img
            className="justice-league"
            alt="Justice league"
            src={justiceLeague1}
          />
        </div>

        <div className="top-nav-bar">
          <div className="overlap-3">
            <div className="rectangle-2" />

            <div className="text-wrapper-2">Movies</div>

            <img className="image-2" alt="Image" src={image1} />

            <div className="rectangle-3" />

            <div className="text-wrapper-3">About</div>
          </div>
        </div>
      </div>
    </div>
  );
 
}

export default App;
